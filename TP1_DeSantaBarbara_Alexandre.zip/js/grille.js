/* Classe principale du jeu, c'est une grille de cookies. Le jeu se joue comme
Candy Crush Saga etc... c'est un match-3 game... */
class Grille {

  tabCookies = [];
  tabCookiesCliques = [];
  nbLignes;
  nbColonnes;


  constructor(ligne, colonne) {
    this.nbLignes = ligne;
    this.nbColonnes = colonne;
    this.remplirTableauDeCookies(6);
  }

  /**
   * parcours la liste des divs de la grille et affiche les images des cookies
   * correspondant à chaque case. Au passage, à chaque image on va ajouter des
   * écouteurs de click et de drag'n'drop pour pouvoir interagir avec elles
   * et implémenter la logique du jeu.
   */
  showCookies() {
    let caseDivs = document.querySelectorAll("#grille div");

    caseDivs.forEach((div, index) => {
      let ligne = Math.floor(index / this.nbColonnes);
      let colonne = index % this.nbColonnes;

      console.log("On remplit le div index=" + index + " l=" + ligne + " col=" + colonne);

      let img = this.tabCookies[ligne][colonne].htmlImage;

      img.onclick = (evt) => {
        let imgClick = evt.target;
        let ligne = imgClick.dataset.ligne;
        let colonne = imgClick.dataset.colonne;
        let cookieClique = this.tabCookies[ligne][colonne];
        cookieClique.selectionnee();

        if (this.tabCookiesCliques.length === 0) {
          this.tabCookiesCliques.push(cookieClique);
        }

        else if (this.tabCookiesCliques.length === 1) {
          this.tabCookiesCliques.push(cookieClique);

          if (this.swapPossible()) {
            this.swapCookies();
          }

          this.tabCookiesCliques[0].deselectionnee();
          this.tabCookiesCliques[1].deselectionnee();
          this.tabCookiesCliques = [];
        }
      }

      img.ondragstart = (evt) => {
        let imgClick = evt.target;
        let ligne = imgClick.dataset.ligne;
        let colonne = imgClick.dataset.colonne;
        let cookieOnDrop = this.tabCookies[ligne][colonne];
        this.tabCookiesCliques = [];
        this.tabCookiesCliques.push(cookieOnDrop);
        cookieOnDrop.selectionnee();
      }

      img.ondragover = (evt) => {
        return false;
      }

      img.ondragenter = (evt) => {
        let img = evt.target;
        img.classList.add("grilleDragOver");
      }

      img.ondragleave = (evt) => {
        let img = evt.target;
        img.classList.remove("grilleDragOver");
      }

      img.ondrop = (evt) => {
        let imgOnDrop = evt.target;
        let ligne = imgOnDrop.dataset.ligne;
        let colonne = imgOnDrop.dataset.colonne;
        let cookieOnDrop = this.tabCookies[ligne][colonne];
        this.tabCookiesCliques.push(cookieOnDrop);

        if (this.swapPossible()) {
          this.swapCookies();
        }

        this.tabCookiesCliques[0].deselectionnee();
        this.tabCookiesCliques[1].deselectionnee();
        imgOnDrop.classList.remove("grilleDragOver");
        this.tabCookiesCliques = [];

      }

      div.appendChild(img);
    })
  }



  swapPossible() {
    let firstCookie = this.tabCookiesCliques[0];
    let secondCookie = this.tabCookiesCliques[1];

    return Cookie.distance(firstCookie, secondCookie) === 1;
  }

  swapCookies() {
    let firstCookie = this.tabCookiesCliques[0];
    let secondCookie = this.tabCookiesCliques[1];

    let tmpType = firstCookie.type;
    let tmpImg = firstCookie.htmlImage.src;

    firstCookie.type = secondCookie.type;
    firstCookie.htmlImage.src = secondCookie.htmlImage.src;

    secondCookie.type = tmpType;
    secondCookie.htmlImage.src = tmpImg;

    this.detecterMatch();
  }

  /**
   * Initialisation du niveau de départ. Le paramètre est le nombre de cookies différents
   * dans la grille. 4 types (4 couleurs) = facile de trouver des possibilités de faire
   * des groupes de 3. 5 = niveau moyen, 6 = niveau difficile
   *
   * Améliorations : 1) s'assurer que dans la grille générée il n'y a pas déjà de groupes
   * de trois. 2) S'assurer qu'il y a au moins 1 possibilité de faire un groupe de 3 sinon
   * on a perdu d'entrée. 3) réfléchir à des stratégies pour générer des niveaux plus ou moins
   * difficiles.
   *
   * On verra plus tard pour les améliorations...
   */
  remplirTableauDeCookies(nbDeCookiesDifferents) {
    this.tabCookies = create2DArray(this.nbLignes);
    do {
      for (let ligne = 0; ligne < this.nbLignes; ligne++) {
        for (let colonne = 0; colonne < this.nbColonnes; colonne++) {
          let type = Math.floor(Math.random() * nbDeCookiesDifferents);
          this.tabCookies[ligne][colonne] = new Cookie(type, ligne, colonne);
        }
      }
    } while (this.detecterMatch());
    /*
    for (let i=0;i<this.nbLignes;i++){
      for (let j=0;j<this.nbColonnes;j++){
        let randInt= Math.floor(nbDeCookiesDifferents * Math.random());
        this.tabCookies[i][j] =new Cookie (randInt, i, j);
      }
    }
    */
  }

  detecterMatch() {
    this.compteur = 0;

    for (let ligne = 0; ligne < this.nbLignes; ligne++) {
      let ligneGrille = this.tabCookies[ligne];

      for (let colonne = 0; colonne <= this.nbColonnes - 3; colonne++) {
        let firstCookie = ligneGrille[colonne];
        let secondCookie = ligneGrille[colonne+1];
        let thirdCookie = ligneGrille[colonne+2];

        if (firstCookie.type === secondCookie.type && firstCookie.type === thirdCookie.type) {
          firstCookie.match();
          //this.tabCookies[ligne][colonne]=this.createRandomCookie();
          secondCookie.match();
          //this.tabCookies[ligne][colonne+1]=this.createRandomCookie();
          thirdCookie.match();
          //this.tabCookies[ligne][colonne+2]=this.createRandomCookie();
          this.compteur++;
        }
      }
    }

    for (let colonne = 0; colonne < this.nbColonnes; colonne++) {
      for (let ligne = 0; ligne <= this.nbLignes - 3; ligne++) {
        let firstCookie = this.tabCookies[ligne][colonne];
        let secondCookie = this.tabCookies[ligne+1][colonne];
        let thirdCookie = this.tabCookies[ligne+2][colonne];
  
        if (firstCookie.type === secondCookie.type && firstCookie.type === thirdCookie.type) {
          firstCookie.match();
          //this.tabCookies[ligne][colonne]=this.createRandomCookie();
          secondCookie.match();
          //this.tabCookies[ligne+1][colonne]=this.createRandomCookie();
          thirdCookie.match();
          //this.tabCookies[ligne+2][colonne]=this.createRandomCookie();
          this.compteur++;
        }
      }
    }
    return this.compteur != 0;
  }

  createRandomCookie(){
    let type = Math.floor(Math.random() * 6);
    return new Cookie(type, this.ligne, this.colonne);
  }

}
